# -*- coding: utf-8 -*-

# coding: utf-8
import pandas as pd
#import numpy as np

class Datos:

    # TODO: procesar el fichero para asignar correctamente las variables nominalAtributos, datos y diccionarios
    def __init__(self, nombreFichero):       
        
    def extraeDatos(self,idx):

